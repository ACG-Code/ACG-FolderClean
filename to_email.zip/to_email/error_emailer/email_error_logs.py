import os
import json
from docopt import docopt
from log_emailer import LogEmailer
from datetime import datetime, timedelta
# TODO: Replace this import with one relevant to client
from tm1py_config_connect import ConfigConnector

# Usage:
# Run this with a chore every hour.
# Get every error log in the past hour.

usage = """
email_error_logs.py
Run this with a chore every hour.
Get every error log in the past hour or time specified.

Usage:
  email_error_logs.py [--hours <hours>] [--minutes <minutes>]
  email_error_logs.py (-h | --help)

Options: 
  -h,--help                Display help.
  --hours <hours>          Number of hours ago.
  --minutes <minutes>      Number of minutes ago.
"""

arguments = docopt(usage)

hours_not_set = False
minutes_not_set = False
if arguments['--hours']:
    hours_ago = float(arguments['--hours'])
else:
    hours_not_set = True
    hours_ago = 0.0

if arguments['--minutes']:
    minutes_ago = float(arguments['--minutes'])
else:
    minutes_not_set = True
    minutes_ago = 0.0

# 1 hour by default, clamping arguments to 24 hour limit otherwise.
if hours_not_set and minutes_not_set:
    hours_ago = 1.0
    seconds_ago = 3600.0
else:
    max_hours = 24
    max_minutes = max_hours * 60
    hours_ago = max(min(hours_ago, max_hours), 0.0)
    minutes_ago = max(min(minutes_ago, max_minutes), 0.0)
    seconds_ago = hours_ago * 60.0 * 60.0 + minutes_ago * 60.0
    seconds_ago = max(min(seconds_ago, 86400.0), 0.0)

print(f'Hours ago {hours_ago}')
print(f'Minutes ago {minutes_ago}')
print(f'Seconds ago {seconds_ago}s')

# TODO: Replace this line with the client's connection
tm1 = ConfigConnector.connect_to_standard_objects()
current_datetime = datetime.now()
hour_ago_datetime = current_datetime - timedelta(seconds=seconds_ago)

# TODO: Replace with client path
email_list_path = os.path.join(os.path.dirname(__file__), 'error_email_list.json')
email_list_path = os.path.abspath(email_list_path)

if not os.path.exists(email_list_path):
    emails_error_reporting = {
        'emails' : [
            'vcinardo@acgi.com'
        ]
    }

    with open('error_email_list.json', 'w') as json_file:
        json.dump(emails_error_reporting, json_file, indent=4)

with open(email_list_path, 'r') as json_file:
    emails_error_reporting = json.load(json_file)

# Email error logs, if any.
tm1_server_name = tm1.server.get_server_name()
emails = emails_error_reporting['emails']
error_logs = tm1.server.get_message_log_entries(
    since=hour_ago_datetime,
    level='ERROR'
)

if len(error_logs) == 0:
    print('No error logs found in the last hour.')
    exit(0)

try :
    LogEmailer.send_log_emails(tm1_server_name, emails, error_logs)
except Exception as e:
    print(f'The emails could not be sent: {e}')